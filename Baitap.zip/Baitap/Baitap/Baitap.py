class Node:
    def __init__ (self, StorageCode, StorageName, StorageAddress, itemCount, StorageType, DateR, DateE, StorageItems, NextNode = None):
        self.code = StorageCode
        self.Name = StorageName
        self.Address = StorageAddress
        self.itemCount = itemCount
        self.Type = StorageType
        self.DateR = DateR
        self.DateE = DateE
        self.items = StorageItems
        self.next = NextNode
        return
    def toString(self):
        ItemInStorage = "\nHàng hóa:"
        inform = "Mã kho hàng: " + str(self.code)+ "\nTên kho hàng :"+ str(self.Name)+"\nĐịa điểm: "+ str(self.Address) +"\nTải trọng: "+ str(self.itemCount) +"\nLoại hàng hóa: "+ str(self.Type) +"\nNgày nhập hàng: "+ str(self.DateR) +"\nNgày xuất hàng: "+ str(self.DateE);
        for x in self.items:
            ItemInStorage += '\n' + str(x)

        return "\n" + inform + ItemInStorage + "\n"
    def isBlank(self):
        return not(len(self.items) == int(self.itemCount))

class Linked_List:
    def __init__(self, headNode = None):
        self.head = headNode
        return

def AddHead(ll,p):
    if (ll.head == None):
        ll.head = p
    else:
        p.next = ll.head
        ll.head = p
      
def AddEnd(ll,p):
    if (ll.head == None):
        ll.head = p
    else:
        a = ll.head
        while(a.next != None):
            a = a.next
        a.next = p


def InsertNode(ll,p,index):
    if (index == 0):
        p.next = ll.head.next
        ll.head = p
    if (ll.head == None): 
        ll.head = p
        return
    curNode = ll.head
    while (index != 0):
        index-=1
        curNode = curNode.next
    p.next = curNode.next
    curNode.next = p
def ResetAll(ll):
    p = ll.head
    while (p != None):
        rev = p
        p = p.next
        rev.next = None

def sortList(ll):
    curList = []
    curNode = ll.head
    while (curNode != None):
        curList.append(curNode)
        curNode = curNode.next
    curList.sort(key = lambda node: int(node.itemCount))
    newll = Linked_List()
    ResetAll(ll)
    for i in range(len(curList)):
        AddEnd(newll,curList[i])
        
    return newll


def ReadFile():
    fileName = input("Tên file: ")
    data = open(fileName).readlines()
    return data
def ReadStd(isinfinity = True):
    data = []
    if (isinfinity):
        print("bấm 0 để ngừng đọc input")
        inp =input()
        while(inp != "0"):
            data.append(inp)
            inp = input()
    else: data = input()
    return data

def deleteAt(ll, index):
    curNode = ll.head
    preNode = curNode
    if (index == 0):
        ll.head = ll.head.next
        return
    while (index != 0):
        index-=1
        preNode = curNode
        curNode = curNode.next
    preNode.next = curNode.next

def Convert(x):
    Storage = ''
    extract = x.split(' ')
    itemList = []       
    for i in range(7, len(extract)):
          itemList.append(extract[i])
    Storage = Node(extract[0],extract[1],extract[2],extract[3],extract[4],extract[5],extract[6],itemList)
    return Storage
    
    


def main():
    print("Cấu trúc: <Mã_kho_hàng> <Tên_kho_hàng> <Địa_điểm> <Tải_trọng> <Loại_hàng_hóa> <Ngày/tháng/năm nhập hàng> <Ngày/tháng/năm xuất hàng> <Tất_cả_hàng_hóa>\n")
    print("Đọc từ bàn phím(1)\nĐọc từ file(2)\n");
    inp = ""
    data =[]
    while(inp != '1' and inp != '2'):
        inp = input("Chọn 1 hoặc 2: ")
    if (inp == '1'):
        data = ReadStd()
    else:
        data = ReadFile()
    
    ll = Linked_List()
    for x in data:
        Storage = Convert(x)
        AddEnd(ll,Storage)  
    p = ll.head
    while (p != None):
       print(p.toString())
       p = p.next

    choice = input("Bạn có muốn thêm/bớt phần tử ko .-. ??( 1 | 2 )")
    if (choice == '1' or choice == '2'):
        if (choice == '1'):
            print("Kho hàng: ")
            storage1 = Convert(ReadStd(False))
            index = int(input('Tại vị trí: '))
            InsertNode(ll,storage1,index - 1)
        elif (choice == '2'):
           index = int(input("Xóa ở vị trí: "))
           deleteAt(ll,index - 1)
    p = ll.head
    while (p != None):
       print(p.toString())
       p = p.next
    print("Danh sách sau khi sắp xếp:\n")
    ll = sortList(ll)
    p = ll.head
    while (p != None):
       print(p.toString())
       p = p.next
    newStorage = Convert(input("Thêm kho hàng: "))
    AddEnd(ll,newStorage)
    ll = sortList(ll)
    p = ll.head
    DateList = []
    while (p != None):
       print(p.toString())
       if (p.DateR.find('10/2021') > 0):
           DateList.append(p)
       p = p.next
    print("Tất cả kho nhập ngày 10/2021:\n")
    for x in DateList:
        print(x.toString())


    TaiTrongList = []
    p = ll.head
    while (p != None):
       if (p.isBlank() == True): TaiTrongList.append(p)
       p = p.next
    print("Tất cả kho còn trống:\n")
    for x in TaiTrongList:
        print(x.toString())


    LoaiHangList = []
    p = ll.head
    while (p != None):
        if (p.Type == 'Hang_dong_lanh'): LoaiHangList.append(p)
        p = p.next
    print("Tất cả kho có hàng đông lạnh:\n")
    for x in LoaiHangList:
        print(x.toString())

    sum = 0
    count = 0
    p = ll.head
    while (p != None):
        if (p.Address == 'Đồng_Nai'): 
            count += 1
            sum += int(p.itemCount)
        p = p.next
    print("Trọng tải trung bình: ", sum/count)


    namecount = 0
    p = ll.head
    while (p != None):
        if (p.Name[0] =='K' and p.Name[1] == 'H'):
           namecount += 1
        p = p.next
    print("Có ", namecount," bắt đầu bằng KH")
    
    

if __name__ == "__main__":
    main()

