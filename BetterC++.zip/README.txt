Hướng dẫn sử dụng thư viện BetterCPP.h :D
Thành phần: 
Thư viện hiện tại gồm 2 dạng namespace:
- ...Var: namespace chứa các biến đã tạo sẵn: DimensionalVar, DataStructureVar,...
- ...F: namespace chứa các hàm để xử lý: MathF, Vector2F, GraphF...


Ok giờ chúng ta đi vào từng thành phần nào :)))

MathF:
Công dụng:
sqr(long a);: bình phương số a
Max(long a, long b);: tìm số lớn nhất trong a và b
Min(long a, long b);: tìm số bé nhất trong a và b
GCD(long a, long b);: tìm ước chung lớn nhất của a và b
LCM(long a, long b);: tìm bội chung bé nhất của a và b
isPrime(long a): kiểm tra xem a có phải số nguyên tố hay ko 


*****Dimensional*****
namespace:DimensionalVar, Vector2F

Biến:
Vector2 ten_bien(x,y);
Vector3 ten_bien(x,y,z);

Bonus:
Vector2 và Vector3 có thể được dùng trực tiếp bằng phép +,-,*:

Vector2 a(1,1); Vector2 b(1,2);
Vector2 c = a + b; //c = (2,3)
c = b - a; //c = (0,1)
c = a * 5 // c = (5,5);

Hàm:
long magnitude(Vector2 vector); trả về độ dài vector
long distance(Vector2 toa_do1, Vector2 toa_do2); trả về khoản cách giữa 2 tọa độ

Hiện tại vẫn chưa hỗ trợ hàm cho vector3, vì tui lười :D.
Dimensional có thể được dùng trong các bài tập tìm đường ra khỏi mê cung, tìm đường ngắn nhất
trong ma trận,... và có thể được sử dụng trong các thuật toán nhánh cận, A*,...


*****Cấu trúc dữ liệu*****
namespace DataStructureVar, GraphF
Biến:
hiện tại, cấu trúc dữ liệu mình mới hỗ trợ đồ thị thoi:D
khai báo:

storage a(int D, long Data);
D là đỉnh
Data là trọng số


Graph<size> graph;
size: là số đỉnh lớn nhất bài toán có thể cho

Graph có 4 dạng như hiện tại hàm chỉ hỗ trợ 2 dạng là ListWithData(danh sách kề có trọng số) và
RawInput(là danh sách các cạnh, thường phần lớn các bài tập dữ liệu vào như thế này)
VD: RawInput:
Cho n đỉnh và m cạnh, hãy...
inp:
5 6
1 5 3
2 4 6
3 5 2
1 2 3
3 4 1
4 1 1

Sử dụng:
Graph<10> graph;
graph.Matrix;  (ma trận kề, có dạng int a[][])
graph.Raw_Input;  (danh sách các cạnh, có dạng vector<Vector3> a)
graph.List;  (danh sách kề ko trọng số, có dạng vector<int> a )
graph.ListWithData;   (danh sách kề có trọng số, có dạng vector<storage> a[])


Hàm: 
Chúng ta có thể tà đạo bằng cách đọc số đỉnh n, số cạnh m r dùng hàm:
ReadRawInput(vector<Vector3> &RawInput, int edgeCount, bool haveData);

RawInput: có thể để graph.Raw_Input hoặc biến nào đó có dạng vector<Vector3>
  * dữ liệu sau khi đọc sẽ được đưa vào RawInput
edgeCount: số cạnh (thường là m trong các bài tập)
haveData: có trọng số hay ko (nếu có sẽ là true, ko có là false)

VD:
với số cạnh m và có trọng số:

ReadRawInput(graph.Raw_Input, m, true);

hoặc:

vector<Vector3> a;
ReadRawInput(a, m, true);






ConvertToList(vector<Vector3>& RawInput, vector<storage> ListWithData[]); chuyển từ dạng RawInput 
sang ma trận kề có trọng số
RawInput: đọc ở trên đi :))) làm biếng ghi lại :))
ListWithData[]: ma trận kề có trọng số
Hàm sẽ trả kết quả về biến ListWithData[]

vd:

 ConvertToList(graph.Raw_Input, graph.ListWithData);
 
hoặc:
 vector<Vector3> a; 
 vector<storage> b[100];
 ConvertToList(a,b);




Dijkistra_Setup(long distance[], int startPos,int size); Setup cho hàm Dijkistra_F
distance[]: mảng lưu quãng đường bé nhất từ vị trí bắt đầu đến distance[i]
startPos: vị trí bắt đầu
size: số đỉnh



Dijkistra_F(vector<storage>ListWithData[], int StartD, long distanceL, long Minval[], bool loai[], int dem, int size)
StartD: đỉnh bắt đầu
distaceL: truyền vào số 0
Minval[]: mảng tham chiếu kết quả, sau khi hàm thực hiện xong, con đường ngắn nhất từ đỉnh đầu đến đỉnh I sẽ lưu vào Minval[i];
loai[]: truyền vào mảng bool loai[số đỉnh + 1];
dem: truyền vào số 0
size: truyền vào số đỉnh



Kruscal_Setup(int Parent[], int size);
Parent[]: mảng int có số phần tử lớn hơn hoặc bằng số đỉnh
size: số đỉnh

Kruscal_F(vector<Vector3> &Raw_Input, int Parent[], int Rank[], int size);
Raw_Input: đọc ở trên :Đ
Parent[]: mảng int có số phần tử lớn hơn hoặc bằng số đỉnh + 1 (vd int b[100])
Rank[]: mảng int có số phần tử lớn hơn hoặc bằng số đỉnh + 1(vd int a[100])
size: truyền vào số đỉnh




Chương trình chạy thử:


/////////////////////////////////////////////////////////////



#include <iostream>
#include "BetterCPP.h"

using namespace std;
using namespace DataStructureVar;
using namespace GraphF;
long dis[100];
bool loai[100];
int Par[100], Rank[100];
int main()
{
    int n; int m; int strD = 0; int endD = 0;
    cout << "Nhap so dinh:";
    cin >> n;
    cout << "Nhap so canh:";
    cin >> m;
    cout << "Nhap cac canh:";
    Graph<100> a;
    ReadRawInput(a.Raw_Input, m, true);
    ConvertToList(a.Raw_Input, a.ListWithData);
    cout << "Nhap dinh bat dau: "; cin >> strD;
    Dijkistra_Setup(dis, strD, n);
    Dijkistra_F(a.ListWithData, strD, 0, dis, loai, 0, n);

    for (int i = 1; i <= n; i++)
    {
        cout << "Duong ngan nhat tu " << strD << " den " << i << " la:" << dis[i] << "\n";
    }

    Kruscal_Setup(Par, n);
    long kq = 0;
    Kruscal_F(a.Raw_Input,Par,Rank,n,kq);
    cout << "Cay khung lon nhat la:" << kq;
}
