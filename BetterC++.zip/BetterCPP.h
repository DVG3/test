#include <vector>
#include <string>
#include <algorithm>
#include <cmath>
#include <sstream>
#include <stdio.h>
#include <iostream>

using namespace std;
namespace MathF
{
	long sqr(long a)
	{
		return a * a;
	}
	long Min(long a, long b)
	{
		return a < b ? a : b;
	}
	long Max(long a, long b)
	{
		return a > b ? a : b;
	}
	bool isPrime(long a)
	{
		if (a == 1) return 0;
		if (!(a % 2) || !(a % 3)) return 0;
		long k = -1;
		while (k < sqrt(a))
		{
			k += 6;
			if (a % k == 0 || a % (k + 2) == 0) break;
		}
		return k > sqrt(a);
	}
	long GCD(long a, long b)
	{
		return b ? GCD(b, a % b): a;
	}
	long LCM(long a, long b)
	{
		return(a * b) / GCD(a, b);
	}
}


namespace DimensionalVar
{
	class Vector2
	{
	public:
		Vector2()
		{

		}
		Vector2(int X, int Y)
		{
			x = X;
			y = Y;
		}
		long x;
		long y;
		Vector2 operator+ (const Vector2& other)
		{
			return Vector2(x + other.x, y + other.y);
		}
		Vector2 operator- (const Vector2& other)
		{
			return Vector2(x - other.x, y - other.y);
		}
		bool equal(const Vector2& other)
		{
			if (other.x == x && other.y == y) return true;
			return false;
		}
		Vector2 operator *(const long num)
		{
			return Vector2(x * num, y * num);
		}
		string ToString()
		{
			stringstream ss;
			ss << "(" << x << "," << y << ")";
			return ss.str();
		}
	};
	class Vector3
	{
	public:
		Vector3() {

		}
		Vector3(long X, long Y, long Z)
		{
			x = X;
			y = Y;
			z = Z;
		}
		long x;
		long y;
		long z;
		Vector3 operator+ (const Vector3& other)
		{
			return Vector3(x + other.x, y + other.y, z + other.z);
		}
		Vector3 operator- (const Vector3& other)
		{
			return Vector3(x - other.x, y - other.y, z - other.z);
		}
		bool equal(const Vector3& other)
		{
			if (other.x == x && other.y == y && other.z == z) return true;
			return false;
		}
		Vector3 operator *(const long num)
		{
			return Vector3(x * num, y * num, z * num);
		}
		string ToString()
		{
			stringstream ss;
			ss << "(" << x << "," << y << "," << z << ")";
			return ss.str();
		}
	};
}



namespace DataStructureVar
{
	using namespace DimensionalVar;
	struct storage
	{
		int d;
		long data;
		storage(int D, long DATA)
		{
			d = D;
			data = DATA;
		}
	};


	template <int size>
	class Graph
	{
	public:
		Graph()
		{

		}
		vector<int> List[size];
		vector<storage> ListWithData[size];
		vector<Vector3> Raw_Input;
	 	int Matrix[size][size];	
	private:
		
	};
	template <typename T>
	class Linked_List_Node
	{
	public:
		T data = NULL;
		Linked_List_Node* p = nullptr;
		int index = -1;
		Linked_List_Node(Linked_List_Node* P, T Data, int Index)
		{
			p = P;
			data = Data;
			index = Index;
		}
		Linked_List_Node()
		{
			p = nullptr;
			data = NULL;
			index = -1;
		}
	};
	template <typename T>
	class Linked_List
	{
	public:
		Linked_List_Node<T> *head;
		Linked_List_Node<T> *tail;
	};
	
}
namespace Vector2F
{
	using namespace DataStructureVar;
	using namespace DimensionalVar;

	using namespace MathF;
	long magnitude(Vector2 &a)
	{
		return sqrt(sqr(a.x) + sqr(a.y) );
	}
	long distance(Vector2 Pos1, Vector2 Pos2)
	{
		Vector2 dis = Pos1 - Pos2;
		return(magnitude(dis));
	}
}


namespace Linked_List_F
{
	using namespace DataStructureVar;
	using namespace MathF;
	
}


namespace GraphF
{
	using namespace DataStructureVar;
	using namespace MathF;
	using namespace DimensionalVar;


	
	void ReadRawInput(vector<Vector3> &RawInput, int edgeCount, bool haveData)
	{
		int d1, d2, data = 0;
		for (int i = 0; i < edgeCount; i++)
		{
			if (haveData)
				cin >> d1 >> d2 >> data;
			else cin >> d1 >> d2;
			RawInput.push_back(Vector3(d1,d2,data));
		}
	}
	void ConvertToList(vector<Vector3>& RawInput, vector<storage> ListWithData[])
	{
		int d1, d2; int data;
		for (int j = 0; j < RawInput.size(); j++)
		{
			d1 = RawInput[j].x;
			d2 = RawInput[j].y;
			data = (RawInput[j].z ? RawInput[j].z : 1);
			ListWithData[d1].push_back(DataStructureVar::storage(d2, data));
			ListWithData[d2].push_back(DataStructureVar::storage(d1, data));

		}
	}


	void Dijkistra_F(vector<storage>ListWithData[], int StartD, long distanceL, long Minval[], bool loai[], int dem, int size)
	{

		loai[StartD] = true;
		int minVal = 99999;
		int min_d = StartD;
		for (int i = 0; i < ListWithData[StartD].size(); i++)
		{
			if (!loai[ListWithData[StartD][i].d])
				Minval[ListWithData[StartD][i].d] = Min(Minval[ListWithData[StartD][i].d], ListWithData[StartD][i].data + distanceL);

		}
		if (dem == size) return;
		for (int i = 1; i <= size; i++)
		{
			if (minVal > Minval[i] && Minval[i] && !loai[i])
			{
				minVal = Minval[i];
				min_d = i;
			}
		}

		Dijkistra_F(ListWithData, min_d, Minval[min_d], Minval, loai, dem + 1, size);
	}
	void Dijkistra_Setup(long distance[], int startPos,int size)
	{
		for (int i = 0; i <= size; i++)
		{
			distance[i] = 9999999;
		}
		distance[startPos] = 0;
	}
	

	void Kruscal_Setup(int Parent[], int size)
	{
		for (int i = 1; i <= size; i++)
		{
			Parent[i] = i;
		}
	}


	int FindP(int u, int Parent[])
	{
		if (u != Parent[u]) Parent[u] = FindP(Parent[u],Parent);
		return Parent[u];
	}

	bool Join(int u, int v, int Parent[], int Rank[])
	{
		u = FindP(u, Parent);
		v = FindP(v, Parent);
		if (Rank[u] == Rank[v]) Rank[u]++;
		if (Rank[u] < Rank[v]) Parent[u] = v;
		else Parent[v] = u;
		return true;
	
	}

	
	void Kruscal_F(vector<Vector3> &Raw_Input, int Parent[], int Rank[], int size, long &kq)
	{
		int dem = 0;
		int i = 0;
		long tong = 0;
		sort(Raw_Input.begin(), Raw_Input.end(), [](const Vector3& a, const Vector3& b){return a.z < b.z;});
		while (dem < size - 1)
		{
			if (i == Raw_Input.size()) break;
			if (Join(Raw_Input[i].x, Raw_Input[i].y,Parent,Rank))
			{
				dem++;
				tong += Raw_Input[i].z;
			}
			i++;
		}
		kq = tong;
	}

}